<?php
/*
add_filter( 'allowed_block_types_all', function () {
	return array(
		'core/paragraph',
		'core/heading',
		'core/list',
		'core/table',
		'core/columns',
		'core/table',
		'core/html',
		'acf/image',
		'acf/media-text',
		'acf/brand-table',
		'acf/section',
		'acf/hidden-text',
		'acf/single-brand',
		'acf/link-block',
		'acf/toc-auto',
		'acf/howto',
		'acf/gallery',
		'acf/icon-block',
		'acf/feedback-form',
		'acf/video',
		'acf/matches-cards',
	);
} );*/
