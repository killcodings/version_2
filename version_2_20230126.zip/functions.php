<?php
require_once 'helpers/acf.php';
require_once 'helpers/acf-copy-select.php';
require_once 'helpers/ajax-comments.php';
require_once 'helpers/assets.php';
require_once 'helpers/filters.php';
require_once 'helpers/breadcrumbs.php';
require_once 'helpers/disable-gutenberg-blocks.php';
require_once 'helpers/functions.php';
require_once 'helpers/menu-nav-walker.php';
require_once 'helpers/navigation.php';
require_once 'helpers/toc-generator.php';
require_once 'helpers/feedback-form.php';
require_once 'helpers/translate.php';
