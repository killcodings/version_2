<?php
/*
Template name: Страница Apps Links
Template Post Type: page
*/
get_template_part('index');
