<?php
/*
Template name: Страница Review Links
Template Post Type: page
*/
get_template_part('index');
