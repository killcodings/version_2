<?php
/*
Template name: Страница бренда
Template Post Type: page
*/
get_template_part('index');
