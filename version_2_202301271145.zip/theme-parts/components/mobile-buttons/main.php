<?php

	echo app_get_button( $args['button'],
		"button mobile-button__button {$args['button_style']}",
		$args['relations'],
		$args['custom_colors'] );